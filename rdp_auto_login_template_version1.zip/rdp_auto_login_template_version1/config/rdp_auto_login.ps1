Param($envdomn, $usr, $admLogin, $clrHist, $ipAdr, $prd1rd1)
# If you are getting the error .ps1 script cannot be run. Then execute the below command.
#Set-ExecutionPolicy -Scope CurrentUser -ExecutionPolicy Unrestricted -Force

$ScriptDir = "$PSScriptRoot" # Script path
$EnvConfig = $ScriptDir + "\env_config.ps1"
$FileNameStartWitn = "Rdp_Login"

#=====================================
# Environment Variable Configuration
#=====================================
. $EnvConfig $ScriptDir $FileNameStartWitn $envdomn $usr $prd1rd1

if($exit_flg -eq 1) {
  log "END"
  exit
}

log "Log file is: $logfile"

log "Start time : $(Get-Date)"
log "Domain\UserID : $snusr"

if( $domn -eq "DOMAIN1" ) {
  if( $rEnv -eq "prd1" ) {
    if( $ipAdr -eq "ALL" ) {
	  $rmv_crd = $prd1_DOMAIN1
    }
	else {
	  $rmv_crd = $ipAdr
	}
  }
  else {
    if( $ipAdr -eq "ALL" ) {
	  $rmv_crd = $dr1_DOMAIN1
    }
	else {
	  $rmv_crd = $ipAdr
	}
  }
}
elseif( $domn -eq "DOMAIN2" ) {
   if( $ipAdr -eq "ALL" ) {
     $rmv_crd = $preprod_DOMAIN2
   }
   else {
     $rmv_crd = $ipAdr
   }
}
elseif( $domn -eq "DOMAIN3" ) {
  if( $rEnv -eq "TEST" ) {
    if( $ipAdr -eq "ALL" ) {
	  $rmv_crd = $test_DOMAIN3
    }
	else {
	  $rmv_crd = $ipAdr
	}
  }
  else {
    if( $ipAdr -eq "ALL" ) {
	  $rmv_crd = $dev_DOMAIN3
    }
	else {
	  $rmv_crd = $ipAdr
	}
  }
}

#Cleanup the saved used session
if( $clrHist -eq "Yes" ) {
	clear_saved_session
}

#To ignore the certificate warning on remote desktop connection pop-up
reg add "HKEY_CURRENT_USER\Software\Microsoft\Terminal Server Client" /v "AuthenticationLevelOverride" /t "REG_DWORD" /d 0 /f

connect_rdp $rmv_crd $admLogin

if($closeRemain -eq $true) {
    remove_cr $rmv_crd
	$host.Exit()
}
$count=20
while($Count -ge 0 ) {
    log "$count seconds"
	if((Get-WMIObject -Class Win32_Process -Filter "Name='mstsc.exe'" | where { $_.WorkingSetSize -ge 40000000 -AND $PrevOpendRdpPidList -notcontains $_.Handle })) {
		stop-process (Get-WMIObject -Class Win32_Process -Filter "Name='mstsc.exe'" | where { $_.WorkingSetSize -lt 40000000 -AND $PrevOpendRdpPidList -notcontains $_.Handle }).Handle
		$svr_name = ((Get-WMIObject -Class Win32_Process -Filter "Name='mstsc.exe'" | where { $_.WorkingSetSize -ge 40000000 -AND $PrevOpendRdpPidList -notcontains $_.Handle }).CommandLine -split ' ')[2]
		break;
	}
	else {
		$Count--
	}
	Start-Sleep -Seconds 1
}

if ( $svr_name ) {
    log "Now entering into the rdp" 
    enter_into_rdp $svr_name
}

remove_cr $rmv_crd

log "End time : $(Get-Date)"

#=====================================
# End
#=====================================
