Param($ScriptDir, $FileNameStartWitn, $envdomn, $inputUid, $prd1dr1)

#-----------------------------------
# I/O and LOG file settings
#-----------------------------------
$logDir = $ScriptDir + "\Logs"
$initial = $FileNameStartWitn #"Inc_Active_List"
$logfile = $logDir + "\" + $initial + ".log"
if(!(Test-Path $logDir)) { md $logDir }
echo 'Start Processing...' > $logfile

#-----------------------------------
# Get the registry settings
#-----------------------------------
# import assembly for keyboard input
Add-Type -AssemblyName Microsoft.VisualBasic, System.Web, System.Windows.Forms


#=====================================
# Function to append output in log file
#=====================================
function log($string, $color)
{
   if ($Color -eq $null) {$color = "white"}
   write-host $string -foregroundcolor $color
   $string | out-file -Filepath $logfile -append
}

$rEnv=$envdomn.split('\')[0]
$domn=$envdomn.split('\')[1]
log "$rEnv Environment"
log "$domn Domain"

$usrFile = $ScriptDir + '\' + $domn + "UserID.txt"
$passFile = $ScriptDir + '\' + $domn + "EncPass.txt"
$newFile = $ScriptDir + "\newTmp.txt"
$snusr = $( cat $usrFile 2> $null )
$snpass = $( cat $passFile 2> $null)
$newPass = $( cat $newFile 2> $null)

If ($inputUid -eq $Null -OR $inputUid -eq '') {
  If ($snusr -eq $Null) {
    Log "First time login? Please provide your UserID and try again."
    $exit_flg=1
    exit
  }
}else {
  echo "$domn\$inputUid" | out-file -Filepath $usrFile
  $snusr = $domn + '\' + $inputUid
}

If ($newPass -eq $Null -OR $newPass -eq '') {
  If ($snpass -eq $Null) {
    Log "First time login? Please provide your Password and try again."
    $exit_flg=1
    exit
  }
}else {
  $snpass = ConvertTo-SecureString $newPass | ConvertFrom-SecureString
  $snpass | out-file -Filepath $passFile
}
echo '' > $newFile
$secPass = $snpass | ConvertTo-SecureString

$sv_time = $( (Get-Date).tostring("HHmmss") )
# Below setting is required for html entuty decoding
Add-Type -AssemblyName System.Web

#-----------------------------------
# Variables sets to limit multithreading
#-----------------------------------
$thread_count = 0 
$SleepTimer = 500
$MaxThreads = 7 # Setting up maxmimun threads

#-----------------------------------
# Server list
#-----------------------------------
$prd1_dr1=$prd1dr1

$prd1_DOMAIN1=(
"127.0.0.1",
"127.0.0.2",
"127.0.0.3",
"127.0.0.4"
)

$dr1_DOMAIN1=(
"127.0.0.5",
"127.0.0.6"
)           
            
$preprod_DOMAIN2=(
"127.0.0.7",
"127.0.0.8",
"127.0.0.9",
"127.0.0.10",
"127.0.0.11",
"127.0.0.12"
)

$test_DOMAIN3=(
"127.0.0.13",
"127.0.0.14",
"127.0.0.15",
"127.0.0.16",
"127.0.0.17",
"127.0.0.18"
)

$dev_DOMAIN3=(
"127.0.0.19",
"127.0.0.20",
"127.0.0.21",
"127.0.0.22",
"127.0.0.23",
"127.0.0.24",
"127.0.0.25"
)

#=====================================
# Function to connect rdp
#=====================================
# helper function to locate a open program using by a given Window name
Function FindWindow([string]$windowName, [int]$sleepInterval = 1000) {
  
  [int]$currentTry = 0;
  [bool]$windowFound = $false;
  
  Do {
    Start-Sleep -Milliseconds $sleepInterval
    Try {
	
	    [Microsoft.VisualBasic.Interaction]::AppActivate($windowName)
		
      $windowFound = $true;
    } Catch {
      $windowFound = $false;
    }
	$currentTry++;
    if ( $currentTry -ge "15" )
    {
	  Log "Exit after trying for long time to get the RDP session."
      break;
    }
  } While ($windowFound -eq $false)
  return $windowFound;
}

Function rdp_login($ipAdr, $admLn) {
    cmdkey.exe /generic:$ipAdr /user:$snusr /pass:$( [Runtime.InteropServices.Marshal]::PtrToStringAuto([Runtime.InteropServices.Marshal]::SecureStringToBSTR($secPass)) )
    if ( $admLn -eq 'yes' )
    {
        Log "Admin login to $ipAdr"
        mstsc.exe /v $ipAdr /admin /f
    } else {
        mstsc.exe /v $ipAdr /f
		
    }
}

$closeRemain=$false
#-----------------------------------
# Get the rdp list firsr
#-----------------------------------
$PrevOpendRdpPidList=(Get-WMIObject -Class Win32_Process -Filter "Name='mstsc.exe'" | where { $_.WorkingSetSize -ge 40000000 }).Handle

function connect_rdp($svr_list, $admLogin)
{
    if ( $snusr.split('\')[0] -eq "DOMAIN1" )
    {
        $svr_list | % {
		    rdp_login $_ $admLogin
        }
    } else {
        $svr_list | % {
            rdp_login $_ $admLogin
		}
		$svr_list | % {
			if($closeRemain -eq $true) {
				break;
			}elseif(FindWindow("Windows Security")) {
				$attempts = 1
				while ($True) {
				    if($attempts -eq 3 ) {
						break;
					}elseif((Get-WMIObject -Class Win32_Process -Filter "Name='mstsc.exe'" | where { $_.WorkingSetSize -ge 40000000 -AND $PrevOpendRdpPidList -notcontains $_.Handle })) {
						stop-process (Get-WMIObject -Class Win32_Process -Filter "Name='mstsc.exe'" | where { $_.WorkingSetSize -lt 40000000 -AND $PrevOpendRdpPidList -notcontains $_.Handle }).Handle
						$closeRemain=$true
						log "End time : $(Get-Date)"
						break;
					}
					try {
						Start-Sleep -Milliseconds 1000
						[Microsoft.VisualBasic.Interaction]::AppActivate("Windows Security")
						Start-Sleep -Milliseconds 500
						[System.Windows.Forms.SendKeys]::SendWait($( [Runtime.InteropServices.Marshal]::PtrToStringAuto([Runtime.InteropServices.Marshal]::SecureStringToBSTR($secPass)) )+'{ENTER}')
						log "$attempts Attempt to login.."
					} catch {
						log "$attempts Attempt to login failed seems RDP not yet opened"
						start-sleep 1
					}
					$attempts++
				}
            }
        }
    }  
}

function remove_cr($svr_list)
{
	$svr_list | % {
		cmdkey.exe /delete:$_
	}
}

function enter_into_rdp($svr_name)
{
	if(FindWindow("$svr_name - Remote Desktop Connection")) {
		Start-Sleep -Milliseconds 250
        Log "rdp found"
        [System.Windows.Forms.SendKeys]::SendWait('{ENTER}')
    }
}

function clear_saved_session()
{
	Get-ChildItem "HKCU:\Software\Microsoft\Terminal Server Client" -Recurse | Remove-ItemProperty -Name UsernameHint -Ea 0
	Remove-Item -Path 'HKCU:\Software\Microsoft\Terminal Server Client\servers' -Recurse  2>&1 | Out-Null
	Remove-ItemProperty -Path 'HKCU:\Software\Microsoft\Terminal Server Client\Default' 'MR*'  2>&1 | Out-Null
	$docs = [environment]::getfolderpath("mydocuments") + '\Default.rdp'
	remove-item  $docs  -Force  2>&1 | Out-Null
}
#get-process iexplore | stop-process
